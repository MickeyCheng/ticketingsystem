
package forms;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class frmDashboard extends javax.swing.JFrame {
ResultSet rs;
PreparedStatement pstmt;
Connection conn;
boolean add,edit;
SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
LocalDate today = LocalDate.now();
public static String showQuery;
int minutes =1;
Timer timer = new Timer();

   public frmDashboard() {
        initComponents();
        doConnect();
        fillPendingTickets();
        fillResolvedTickets();
        fillUnassignedTickets();
        fillClosedTickets();
        fillUnassignedReq();
        fillPendingReq();
        fillResolvedReq();
        fillClosedReq();
        setExtendedState(frmDashboard.MAXIMIZED_BOTH);
        getDate();  
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                try{
                    rs.close();
                    conn.close();
                    pstmt.close();
                }catch(SQLException e){
                    e.getMessage();
                }
                doConnect();
                fillPendingTickets();
                fillResolvedTickets();
                fillUnassignedTickets();
                fillUnassignedReq();
                fillPendingReq();
                fillResolvedReq();
                getDate();  
            }
        }, 0,1000*60 * minutes);
    }
    private void fillClosedReq(){
        try{
                String getUnassignTix = "select * from tblTicket where ti_status=? "
                        + " and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getUnassignTix);
            pstmt.setString(1, "CLOSED");
            pstmt.setString(2, "CHANGE REQUEST");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblClosedReq.setText(String.valueOf(getCount));
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private void getDate(){
        LocalDate today = LocalDate.now();    
    }
    private void fillResolvedReq(){
        try{
            String getResolvedTix = "select * from tblTicket where ti_status=? and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getResolvedTix);
            pstmt.setString(1,"RESOLVED");
            pstmt.setString(2,"CHANGE REQUEST");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblResolveReq.setText(String.valueOf(getCount));
        }catch(SQLException e){
            e.getMessage();
        }
    }
    private void fillPendingReq(){
        try{
            String getPendingTix = "select * from tblTicket where ti_status=? and ti_assigned<>? and ti_dateRaised between ? and ?"
                    + "and ti_type=?";
            pstmt = conn.prepareStatement(getPendingTix);
            pstmt.setString(1,"PENDING");
            pstmt.setString(2,"UNASSIGNED");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            pstmt.setString(5,"CHANGE REQUEST");
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblPendingReq.setText(String.valueOf(getCount));
        }catch(SQLException e){
            e.getMessage();
        }
    }
    private void fillUnassignedReq(){
        try{
                String getUnassignTix = "select * from tblTicket where ti_status=? "
                        + "and ti_assigned=? and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getUnassignTix);
            pstmt.setString(1, "PENDING");
            pstmt.setString(2,"UNASSIGNED");
            pstmt.setString(3, "CHANGE REQUEST");
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(5, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblUnassignedReq.setText(String.valueOf(getCount));
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private void fillClosedTickets(){
        try{
                String getUnassignTix = "select * from tblTicket where ti_status=? "
                        + " and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getUnassignTix);
            pstmt.setString(1, "CLOSED");
            pstmt.setString(2, "ISSUE - TICKET");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblClosedTickets.setText(String.valueOf(getCount));
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private void fillUnassignedTickets(){
        try{
//            String getUnassignTix = "select * from tblTicket where ti_status='PENDING' and ti_assigned=''"
//                    + "and ti_type='ISSUE - TICKET'";
                String getUnassignTix = "select * from tblTicket where ti_status=? "
                        + "and ti_assigned=? and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getUnassignTix);
            pstmt.setString(1, "PENDING");
            pstmt.setString(2,"UNASSIGNED");
            pstmt.setString(3, "ISSUE - TICKET");
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(5, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblUnassignedTickets.setText(String.valueOf(getCount));
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
   private void fillResolvedTickets(){
        try{
            String getResolvedTix = "select * from tblTicket where ti_status=? and ti_type=? and ti_dateRaised between ? and ?";
            pstmt = conn.prepareStatement(getResolvedTix);
            pstmt.setString(1,"RESOLVED");
            pstmt.setString(2,"ISSUE - TICKET");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblResolvedTickets.setText(String.valueOf(getCount));
        }catch(SQLException e){
            e.getMessage();
        }
    }
    private void fillPendingTickets(){
        try{
            String getPendingTix = "select * from tblTicket where ti_status=? and ti_assigned<>? and ti_dateRaised between ? and ?"
                    + "and ti_type=?";
            pstmt = conn.prepareStatement(getPendingTix);
            pstmt.setString(1,"PENDING");
            pstmt.setString(2,"UNASSIGNED");
            pstmt.setString(3, String.valueOf(today.withDayOfMonth(1)));
            pstmt.setString(4, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
            pstmt.setString(5,"ISSUE - TICKET");
            rs = pstmt.executeQuery();
            int getCount=0;
            while (rs.next()){
                getCount++;
            }
            lblPendingTickets.setText(String.valueOf(getCount));
        }catch(SQLException e){
            e.getMessage();
        }
    }
   private void doConnect(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
//        conn = DriverManager.getConnection("jdbc:mysql://192.168.1.13/dbticketing","iSoft","iSoft123");
    }catch(SQLException | ClassNotFoundException e){
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblUnassignedTickets = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        lblPendingTickets = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        lblClosedReq = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        lblResolveReq = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        lblPendingReq = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        lblUnassignedReq = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        lblResolvedTickets = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        lblClosedTickets = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(255, 102, 0));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("UNASSIGNED");
        jPanel9.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        lblUnassignedTickets.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblUnassignedTickets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUnassignedTickets.setText("0");
        lblUnassignedTickets.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUnassignedTicketsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUnassignedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUnassignedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel9.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 310, 270));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(153, 0, 0));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("PENDING");
        jPanel10.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        lblPendingTickets.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblPendingTickets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPendingTickets.setText("0");
        lblPendingTickets.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPendingTicketsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPendingTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPendingTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel10.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jPanel4.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 310, 270));

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel34.setBackground(new java.awt.Color(153, 153, 0));
        jPanel34.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblClosedReq.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblClosedReq.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClosedReq.setText("0");
        lblClosedReq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblClosedReqMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblClosedReq, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblClosedReq, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel34.add(jPanel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jLabel28.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("CLOSED");
        jPanel34.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        jPanel5.add(jPanel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 410, 310, 270));

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel32.setBackground(new java.awt.Color(0, 51, 0));
        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblResolveReq.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblResolveReq.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblResolveReq.setText("0");
        lblResolveReq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblResolveReqMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblResolveReq, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblResolveReq, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel32.add(jPanel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jLabel26.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("RESOLVED");
        jPanel32.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        jPanel6.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 410, 310, 270));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel30.setBackground(new java.awt.Color(102, 0, 0));
        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("PENDING");
        jPanel30.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        lblPendingReq.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblPendingReq.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPendingReq.setText("0");
        lblPendingReq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPendingReqMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPendingReq, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPendingReq, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel30.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jPanel7.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 410, 310, 270));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel28.setBackground(new java.awt.Color(255, 102, 0));
        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("UNASSIGNED");
        jPanel28.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        lblUnassignedReq.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblUnassignedReq.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUnassignedReq.setText("0");
        lblUnassignedReq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblUnassignedReqMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUnassignedReq, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUnassignedReq, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel28.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jPanel8.add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 310, 270));

        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("CHANGE REQUEST");
        jPanel21.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 290, 40));

        jPanel1.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 360, 310, 40));

        jLabel3.setText("-------------------------------------------------------------------------------------------------------------------------------");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 510, -1));

        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel23.setBackground(new java.awt.Color(0, 51, 0));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblResolvedTickets.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblResolvedTickets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblResolvedTickets.setText("0");
        lblResolvedTickets.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblResolvedTicketsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblResolvedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblResolvedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel23.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jLabel18.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("RESOLVED");
        jPanel23.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        jPanel15.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 70, 310, 270));

        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel26.setBackground(new java.awt.Color(153, 153, 0));
        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblClosedTickets.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblClosedTickets.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClosedTickets.setText("0");
        lblClosedTickets.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblClosedTicketsMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblClosedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblClosedTickets, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel26.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 150, -1));

        jLabel20.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 36)); // NOI18N
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("CLOSED");
        jPanel26.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 60));

        jPanel25.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 270, 220));

        jPanel1.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 70, 310, 270));

        jLabel21.setText("-------------------------------------------------------------------------------------------------------------------------------");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 370, 510, -1));

        jLabel5.setText("-------------------------------------------------------------------------------------------------------------------------------");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 510, -1));

        jPanel36.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("TICKET");
        jPanel36.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 290, 40));

        jPanel1.add(jPanel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, 310, 40));

        jLabel29.setText("-------------------------------------------------------------------------------------------------------------------------------");
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 30, 510, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1410, 690));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblPendingTicketsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPendingTicketsMouseClicked
        showQuery = "PENDING TICKETS";
        if(evt.getClickCount() == 2 & !evt.isConsumed()){
            evt.consume();
            try{
                fmrTicketing obj = new fmrTicketing();
                obj.setVisible(true);
                this.dispose();
                rs.close();
                pstmt.close();
                conn.close();
            }catch(SQLException e){
                e.getMessage();
            }
        }
    }//GEN-LAST:event_lblPendingTicketsMouseClicked

    private void lblUnassignedTicketsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUnassignedTicketsMouseClicked
        showQuery = "UNASSIGNED TICKETS";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        }        
    }//GEN-LAST:event_lblUnassignedTicketsMouseClicked

    private void lblResolvedTicketsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblResolvedTicketsMouseClicked
        showQuery = "RESOLVED TICKETS";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        } 
    }//GEN-LAST:event_lblResolvedTicketsMouseClicked

    private void lblPendingReqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPendingReqMouseClicked
        showQuery = "PENDING REQUEST";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        } 
    }//GEN-LAST:event_lblPendingReqMouseClicked

    private void lblUnassignedReqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblUnassignedReqMouseClicked
        showQuery = "UNASSIGNED REQUEST";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        } 
    }//GEN-LAST:event_lblUnassignedReqMouseClicked

    private void lblResolveReqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblResolveReqMouseClicked
        showQuery = "RESOLVED REQUEST";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        }
    }//GEN-LAST:event_lblResolveReqMouseClicked

    private void lblClosedTicketsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblClosedTicketsMouseClicked
        showQuery = "CLOSED TICKETS";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        }
    }//GEN-LAST:event_lblClosedTicketsMouseClicked

    private void lblClosedReqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblClosedReqMouseClicked
        showQuery = "CLOSED REQUEST";
        if (evt.getClickCount() == 2 && !evt.isConsumed()){
            evt.consume();
                try{
                    fmrTicketing obj = new fmrTicketing();
                    obj.setVisible(true);
                    this.dispose();
                    rs.close();
                    pstmt.close();
                    conn.close();
                }catch(SQLException e){
                    e.getMessage();
                }
        }
    }//GEN-LAST:event_lblClosedReqMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblClosedReq;
    private javax.swing.JLabel lblClosedTickets;
    private javax.swing.JLabel lblPendingReq;
    private javax.swing.JLabel lblPendingTickets;
    private javax.swing.JLabel lblResolveReq;
    private javax.swing.JLabel lblResolvedTickets;
    private javax.swing.JLabel lblUnassignedReq;
    private javax.swing.JLabel lblUnassignedTickets;
    // End of variables declaration//GEN-END:variables
}
