
package forms;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import net.proteanit.sql.DbUtils;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
public class fmrTicketing extends javax.swing.JFrame {
ResultSet rs;
PreparedStatement pstmt;
Connection conn;
boolean add,edit;
int getMaxTicket;
public static String getType,getCategory;
LocalDate today = LocalDate.now();
SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
String getDateFrom, getDateTo;
    public fmrTicketing() {
        initComponents();
        doConnect();
        disableTexts();
        clearTexts();
        fillComboClient();
        fillComboStatus();
        fillComboCategory();
        fillAssignedTo();
        fillType();
        tblTicket.setAutoCreateRowSorter(true);
        setLocationRelativeTo(null);
        setExtendedState(fmrTicketing.MAXIMIZED_BOTH);
        fillTypeCategory();
        showTicketTable();
    }
    private void getDate(){
    }
    private void fillTablePending(){
    String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"PENDING");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
    }
    private void fillTypeCategory(){
        cmbTypeCategory.removeAllItems();
        cmbTypeCategory.addItem("ALL");
        cmbTypeCategory.addItem("ISSUE - TICKET");
        cmbTypeCategory.addItem("CHANGE REQUEST");
    }
    private void fillType(){
        cmbType.removeAllItems();
        cmbType.addItem("");
        cmbType.addItem("ISSUE - TICKET");
        cmbType.addItem("CHANGE REQUEST");
        cmbType.addItem("OTHERS");
        cmbType.setSelectedIndex(-1);
    }
    private void fillAssignedTo(){
        cmbAssignedTo.removeAllItems();
        try{
            pstmt = conn.prepareStatement("SELECT uc_username from tblUserControl order by uc_username");
            rs = pstmt.executeQuery();
            while(rs.next()){
                cmbAssignedTo.addItem(rs.getString("uc_username"));
            }
            pstmt.close();
            cmbAssignedTo.setSelectedIndex(-1);
        }catch(SQLException e){
            e.getMessage();
        }
        
    }
    
    private void fillComboCategory(){
        cmbCategory.removeAllItems();
        cmbCategory.addItem("");
        cmbCategory.addItem("SYSTEM ISSUE");
        cmbCategory.addItem("OPERATING SYSTEM");
        cmbCategory.addItem("HARDWARE");
        cmbCategory.addItem("SOFTWARE");
        cmbCategory.addItem("NETWORKING");
        cmbCategory.addItem("STATIONARY");
        cmbCategory.addItem("OTHER");
        cmbCategory.setSelectedIndex(-1);
    }
    private void fillComboStatus(){
        cmbStatus.removeAllItems();
        cmbStatus.addItem("");
        cmbStatus.addItem("PENDING");
        cmbStatus.addItem("RESOLVED");
        cmbStatus.addItem("CLOSED");
        cmbStatus.setSelectedIndex(-1);
    }
    private void fillComboClient(){
        cmbClient.removeAllItems();
        try{
            pstmt = conn.prepareStatement("select cd_name from tblClientDetails order by cd_name");
            rs = pstmt.executeQuery();
            while (rs.next()){
                cmbClient.addItem(rs.getString("cd_name"));
            }
            cmbClient.setSelectedIndex(-1);
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();
        }
    }
    private void enableTexts(){
        txtAssignee.setEnabled(true);
        txtDescription.setEnabled(true);
        cmbAssignedTo.setEnabled(true);
        cmbCategory.setEnabled(true);
        cmbClient.setEnabled(true);
        cmbStatus.setEnabled(true);
        cmbType.setEnabled(true);
    }
    private void disableTexts(){
        txtAssignee.setEnabled(false);
        txtDescription.setEnabled(false);
        cmbAssignedTo.setEnabled(false);
        cmbCategory.setEnabled(false);
        cmbClient.setEnabled(false);
        cmbStatus.setEnabled(false);
        cmbType.setEnabled(false);
    }
    private void clearTexts(){
        txtDescription.setText("");
        txtAssignee.setText("");
        cmbAssignedTo.setSelectedIndex(-1);
        cmbCategory.setSelectedIndex(-1);
        cmbClient.setSelectedIndex(-1);
        cmbStatus.setSelectedIndex(-1);
        cmbType.setSelectedIndex(-1);
        lblID.setText("");
    }   
    private void getNextTicketID(){
        try{
            pstmt = conn.prepareStatement("SELECT ti_id from tblTicket order by ti_id DESC LIMIT 1");
            rs = pstmt.executeQuery();
            if (rs.next()){
                getMaxTicket = rs.getInt("ti_id");
                getMaxTicket++;
            }else{
                getMaxTicket=1;
            }
            lblID.setText(String.valueOf(getMaxTicket));
        }catch(SQLException e){
            e.getMessage();
        }
    }
    private void doConnect(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
//        conn = DriverManager.getConnection("jdbc:mysql://192.168.1.13/dbticketing","iSoft","iSoft123");
    }catch(SQLException | ClassNotFoundException e){
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        btnAdd = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        txtAssignee = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dateTicket = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescription = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        cmbClient = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        cmbAssignedTo = new javax.swing.JComboBox<>();
        lblID = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        cmbType = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        btnDashboard = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblTicket = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        dateFrom = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dateTo = new com.toedter.calendar.JDateChooser();
        btnShow = new javax.swing.JButton();
        cmbTypeCategory = new javax.swing.JComboBox<>();
        jPanel9 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mnuLogout = new javax.swing.JMenuItem();
        mnuExit = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        mnuUserMaster = new javax.swing.JMenuItem();
        mnuClientMaster = new javax.swing.JMenuItem();
        menu4 = new javax.swing.JMenu();
        mnuChangePassword = new javax.swing.JMenuItem();
        mnuDashboard = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        mnuTixUnassign = new javax.swing.JMenuItem();
        mnuTixPending = new javax.swing.JMenuItem();
        mnuTixResolve = new javax.swing.JMenuItem();
        mnuTixClose = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        mnuCRUnassign = new javax.swing.JMenuItem();
        mnuCRPending = new javax.swing.JMenuItem();
        mnuCRResolved = new javax.swing.JMenuItem();
        mnuCRClosed = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 770, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 10, 770, -1));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(153, 153, 153));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAdd.setText("ADD");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel5.add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 90, 50));

        btnEdit.setText("EDIT");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });
        jPanel5.add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(145, 10, 90, 50));

        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        jPanel5.add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 90, 50));

        btnSave.setText("SUBMIT");
        btnSave.setPreferredSize(new java.awt.Dimension(55, 23));
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel5.add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 85, 50));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 200, 250, 170));

        txtAssignee.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        txtAssignee.setText("TICKET ID:");
        jPanel4.add(txtAssignee, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 230, 30));

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel2.setText("TICKET DATE:");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 130, 30));

        jLabel3.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel3.setText("TICKET ID:");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 30));

        dateTicket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dateTicketMouseReleased(evt);
            }
        });
        jPanel4.add(dateTicket, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 230, 30));

        jLabel4.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel4.setText("RAISED BY:");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 130, 30));

        jLabel5.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel5.setText("TICKET DESCRIPTION:");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, 180, 30));

        txtDescription.setColumns(20);
        txtDescription.setRows(5);
        jScrollPane1.setViewportView(txtDescription);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 250, 120));

        jLabel7.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel7.setText("CLIENT:");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 130, 30));

        jLabel8.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel8.setText("CATEGORY:");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 130, 30));

        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(cmbCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 230, 30));

        jLabel9.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel9.setText("STATUS:");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 130, 30));

        cmbClient.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(cmbClient, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 230, 30));

        jLabel10.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel10.setText("ASSIGNED TO:");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 130, 30));

        cmbAssignedTo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(cmbAssignedTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 230, 30));

        lblID.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        lblID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblID.setText("TICKET ID:");
        jPanel4.add(lblID, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 80, 30));

        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(cmbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 230, 30));

        jLabel11.setFont(new java.awt.Font("Franklin Gothic Demi Cond", 0, 18)); // NOI18N
        jLabel11.setText("TYPE:");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 130, 30));

        cmbType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(cmbType, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 230, 30));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 650, 400));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 80, 670, 420));

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnDashboard.setText("DASHBOARD");
        btnDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDashboardActionPerformed(evt);
            }
        });
        jPanel6.add(btnDashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 160, 40));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 640, 60));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblTicket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblTicket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTicketMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblTicket);

        jPanel7.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 90, 620, 320));

        jPanel8.setBackground(new java.awt.Color(153, 153, 153));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dateFrom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dateFromMouseReleased(evt);
            }
        });
        jPanel8.add(dateFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 100, 40));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("FROM:");
        jPanel8.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 60, 40));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("TO:");
        jPanel8.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 50, 40));

        dateTo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                dateToMouseReleased(evt);
            }
        });
        jPanel8.add(dateTo, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 110, 40));

        btnShow.setText("SHOW");
        btnShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowActionPerformed(evt);
            }
        });
        jPanel8.add(btnShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, 70, 40));

        cmbTypeCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel8.add(cmbTypeCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, 170, 40));

        jPanel7.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 620, 60));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 640, 420));

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 520, 1320, 140));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1450, 670));

        jMenu1.setText("File");

        mnuLogout.setText("Log Out");
        mnuLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuLogoutActionPerformed(evt);
            }
        });
        jMenu1.add(mnuLogout);

        mnuExit.setText("Exit");
        mnuExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuExitActionPerformed(evt);
            }
        });
        jMenu1.add(mnuExit);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Masters");

        mnuUserMaster.setText("User Master");
        mnuUserMaster.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuUserMasterActionPerformed(evt);
            }
        });
        jMenu3.add(mnuUserMaster);

        mnuClientMaster.setText("Client Master");
        mnuClientMaster.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuClientMasterActionPerformed(evt);
            }
        });
        jMenu3.add(mnuClientMaster);

        jMenuBar1.add(jMenu3);

        menu4.setText("Tools");

        mnuChangePassword.setText("Change Password");
        mnuChangePassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuChangePasswordActionPerformed(evt);
            }
        });
        menu4.add(mnuChangePassword);

        mnuDashboard.setText("Dashboard");
        mnuDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuDashboardActionPerformed(evt);
            }
        });
        menu4.add(mnuDashboard);

        jMenuBar1.add(menu4);

        jMenu5.setText("Tickets");

        mnuTixUnassign.setText("View Unassigned Tickets");
        mnuTixUnassign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTixUnassignActionPerformed(evt);
            }
        });
        jMenu5.add(mnuTixUnassign);

        mnuTixPending.setText("View Pending Tickets");
        mnuTixPending.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTixPendingActionPerformed(evt);
            }
        });
        jMenu5.add(mnuTixPending);

        mnuTixResolve.setText("View  Resolved Tickets");
        mnuTixResolve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTixResolveActionPerformed(evt);
            }
        });
        jMenu5.add(mnuTixResolve);

        mnuTixClose.setText("View Closed Tickets");
        mnuTixClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuTixCloseActionPerformed(evt);
            }
        });
        jMenu5.add(mnuTixClose);

        jMenuBar1.add(jMenu5);

        jMenu6.setText("Change Requests");

        mnuCRUnassign.setText("View Unassigned CR");
        mnuCRUnassign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCRUnassignActionPerformed(evt);
            }
        });
        jMenu6.add(mnuCRUnassign);

        mnuCRPending.setText("View Pending CR");
        mnuCRPending.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCRPendingActionPerformed(evt);
            }
        });
        jMenu6.add(mnuCRPending);

        mnuCRResolved.setText("View Resolved CR");
        mnuCRResolved.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCRResolvedActionPerformed(evt);
            }
        });
        jMenu6.add(mnuCRResolved);

        mnuCRClosed.setText("View Closed CR");
        mnuCRClosed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCRClosedActionPerformed(evt);
            }
        });
        jMenu6.add(mnuCRClosed);

        jMenuBar1.add(jMenu6);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dateTicketMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateTicketMouseReleased

    }//GEN-LAST:event_dateTicketMouseReleased

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        enableTexts();
        add=true;
        edit=false;
        clearTexts();
        btnEdit.setEnabled(false);
        getNextTicketID();
        txtAssignee.setText(frmLogin.username);
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        if(cmbStatus.getSelectedIndex() == -1 || cmbCategory.getSelectedIndex() == -1 || cmbClient.getSelectedIndex() == -1 
                 || dateTicket.getDate()==null || cmbType.getSelectedIndex() == -1){
            JOptionPane.showMessageDialog(this, "PLEASE COMPLETE ALL TICKET DETAILS","TICKET",JOptionPane.WARNING_MESSAGE);
        }else{
            if(add==true && edit==false){
                try{
                    String insertTicket = "INSERT INTO tblTicket (ti_id,ti_client,ti_dateRaised,ti_description,"
                            + "ti_status,ti_category,ti_assignee,ti_assigned,ti_type)values(?,?,?,?,?,?,?,?,?)";
                    pstmt = conn.prepareStatement(insertTicket);
                    pstmt.setInt(1, getMaxTicket);
                    pstmt.setString(2, cmbClient.getSelectedItem().toString());
                    Date getDate = dateTicket.getDate();
                    pstmt.setString(3,String.valueOf(sdfDate.format(getDate)));
                    pstmt.setString(4,txtDescription.getText());
                    pstmt.setString(5,cmbStatus.getSelectedItem().toString());
                    pstmt.setString(6,cmbCategory.getSelectedItem().toString());
                    pstmt.setString(7,txtAssignee.getText());
                    String getAssigned;
                    if (cmbAssignedTo.getSelectedIndex()==-1){
                        getAssigned="UNASSIGNED";
                    }else{
                        getAssigned = cmbAssignedTo.getSelectedItem().toString();
                    }
                    pstmt.setString(8,getAssigned);
                    pstmt.setString(9,cmbType.getSelectedItem().toString());
                    pstmt.execute();
                    pstmt.close();
                    JOptionPane.showMessageDialog(this, "TICKED RAISED");
                    clearTexts();
                    disableTexts();
                    fillTablePending();
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(this, e.getMessage());
                }
            }else if(add==false && edit==true){
                try{
                    String editTicket = "UPDATE tblTicket set ti_client=?,ti_dateRaised=?,ti_description=?,"
                            + "ti_status=?,ti_category=?,ti_assignee=?,ti_assigned=?,ti_type=? where ti_id=?";
                    pstmt = conn.prepareStatement(editTicket);
                    pstmt.setString(1, cmbClient.getSelectedItem().toString());
                    Date getDate = dateTicket.getDate();
                    pstmt.setString(2,String.valueOf(sdfDate.format(getDate)));
                    pstmt.setString(3,txtDescription.getText());
                    pstmt.setString(4,cmbStatus.getSelectedItem().toString());
                    pstmt.setString(5,cmbCategory.getSelectedItem().toString());
                    pstmt.setString(6,txtAssignee.getText());
                    String getAssigned;
                    if (cmbAssignedTo.getSelectedIndex()==-1){
                        getAssigned="UNASSIGNED";
                    }else{
                        getAssigned = cmbAssignedTo.getSelectedItem().toString();
                    }
                    pstmt.setString(7,getAssigned);
                    pstmt.setString(8,cmbType.getSelectedItem().toString());
                    pstmt.setInt(9,Integer.valueOf(lblID.getText()));
                    pstmt.execute();
                    pstmt.close();
                    JOptionPane.showMessageDialog(this, "TICKED STATUS UPDATED");
                    clearTexts();
                    fillTablePending();
                    disableTexts();
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(this, e.getMessage());
                }
            }
        
        }
    }//GEN-LAST:event_btnSaveActionPerformed

    private void dateFromMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateFromMouseReleased

    }//GEN-LAST:event_dateFromMouseReleased

    private void dateToMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dateToMouseReleased

    }//GEN-LAST:event_dateToMouseReleased

    private void btnShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowActionPerformed
        Date getFromDate = dateFrom.getDate();
        Date getToDate = dateTo.getDate();
        if (getFromDate == null && getToDate == null){
            JOptionPane.showMessageDialog(this, "PLEASE CHOOSE A DATE RANGE","TICKETING",JOptionPane.WARNING_MESSAGE);
        }else{
        if (cmbTypeCategory.getSelectedItem().equals("ISSUE - TICKET")){
            String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_type=? and ti_status=? order by ti_id";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(sdfDate.format(getFromDate)));
                pstmt.setString(2, String.valueOf(sdfDate.format(getToDate)));
                pstmt.setString(3,"ISSUE - TICKET");
                pstmt.setString(4, "PENDING");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }else if(cmbTypeCategory.getSelectedItem().equals("ALL")){
            String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=? order by ti_id";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(sdfDate.format(getFromDate)));
                pstmt.setString(2, String.valueOf(sdfDate.format(getToDate)));
                pstmt.setString(3, "PENDING");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }     
        }else if(cmbTypeCategory.getSelectedItem().equals("CHANGE REQUEST")){
            String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ?  and ti_type=? and ti_status=? order by ti_status";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(sdfDate.format(getFromDate)));
                pstmt.setString(2, String.valueOf(sdfDate.format(getToDate)));
                pstmt.setString(3, "CHANGE REQUEST");
                pstmt.setString(4, "PENDING");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }     
        }  
        }
    }//GEN-LAST:event_btnShowActionPerformed
    private void showTicketTable(){
        if (frmDashboard.showQuery == "UNASSIGNED TICKETS") {
            String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_assigned=? and ti_type=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"UNASSIGNED");
                pstmt.setString(4,"ISSUE - TICKET");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }else if(frmDashboard.showQuery == "PENDING TICKETS"){
                String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_assigned<>? and ti_status=? and ti_type=? ";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"UNASSIGNED");
                pstmt.setString(4,"PENDING");
                pstmt.setString(5,"ISSUE - TICKET");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }  
            }else if( frmDashboard.showQuery =="RESOLVED TICKETS"){
                 String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=? and ti_type=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"RESOLVED");
                pstmt.setString(4,"ISSUE - TICKET");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }else if( frmDashboard.showQuery =="UNASSIGNED REQUEST"){
                 String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_type=? and ti_assigned=? and ti_status=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"CHANGE REQUEST");
                pstmt.setString(4,"UNASSIGNED");                
                pstmt.setString(5,"PENDING");                
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }else if(frmDashboard.showQuery == "PENDING REQUEST"){
                String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_assigned<>? and ti_status=? and ti_type=? ";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"UNASSIGNED");
                pstmt.setString(4,"PENDING");
                pstmt.setString(5,"CHANGE REQUEST");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }  
            }else if( frmDashboard.showQuery =="RESOLVED REQUEST"){
                 String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=? and ti_type=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"RESOLVED");
                pstmt.setString(4,"CHANGE REQUEST");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }else if( frmDashboard.showQuery =="CLOSED TICKETS"){
                 String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=? and ti_type=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"CLOSED");
                pstmt.setString(4,"ISSUE - TICKET");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }else if( frmDashboard.showQuery =="CLOSED REQUEST"){
                 String fetchTicketData = "Select ti_id,ti_client,ti_dateRaised,ti_description,ti_assigned,ti_type from tblTicket "
                    + "where ti_dateRaised between ? and ? and ti_status=? and ti_type=?";
            try{
                pstmt = conn.prepareStatement(fetchTicketData);
                pstmt.setString(1, String.valueOf(today.withDayOfMonth(1)));
                pstmt.setString(2, String.valueOf(today.withDayOfMonth(today.lengthOfMonth())));
                pstmt.setString(3,"CLOSED");
                pstmt.setString(4,"CHANGE REQUEST");
                rs = pstmt.executeQuery();
                tblTicket.setModel(DbUtils.resultSetToTableModel(rs));
                pstmt.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }   
            }
    }
    private void tblTicketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTicketMouseClicked
        int row = tblTicket.getSelectedRow();
        int ba = tblTicket.convertRowIndexToModel(row);
        String tblClick = tblTicket.getModel().getValueAt(ba, 0).toString();
        String fetchData = "Select * from tblTicket where ti_id=?";
        try{
            pstmt = conn.prepareStatement(fetchData);
            pstmt.setString(1, tblClick);
            rs = pstmt.executeQuery();
            if(rs.next()){               
                txtAssignee.setText(rs.getString("ti_assignee"));
                txtDescription.setText(rs.getString("ti_description"));
                lblID.setText(String.valueOf(rs.getInt("ti_id")));
                cmbAssignedTo.setSelectedItem(rs.getString("ti_assigned"));
                cmbCategory.setSelectedItem(rs.getString("ti_category"));
                cmbClient.setSelectedItem(rs.getString("ti_client"));
                cmbStatus.setSelectedItem(rs.getString("ti_status"));
                cmbType.setSelectedItem(rs.getString("ti_type"));
                dateTicket.setDate(sdfDate.parse(rs.getString("ti_dateRaised")));
                pstmt.close();
            }
        }catch(SQLException | ParseException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_tblTicketMouseClicked

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        btnAdd.setEnabled(false);
        enableTexts();
        add = false;
        edit = true;
        txtAssignee.setText(frmLogin.username);
        
            frmTicketStatus obj = new frmTicketStatus();
            obj.setVisible(true);
            
        
    }//GEN-LAST:event_btnEditActionPerformed

    private void mnuChangePasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuChangePasswordActionPerformed
        frmChangePassword obj = new frmChangePassword();
        obj.setVisible(true);
    }//GEN-LAST:event_mnuChangePasswordActionPerformed

    private void mnuTixUnassignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTixUnassignActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "PENDING");
            param.put("showType", "ISSUE - TICKET");
            param.put("showAssigned", "UNASSIGNED");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repUnassignedTix.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }      
    }//GEN-LAST:event_mnuTixUnassignActionPerformed

    private void mnuTixPendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTixPendingActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "PENDING");
            param.put("showType", "ISSUE - TICKET");
            param.put("showAssigned", "UNASSIGNED");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repPendingTix.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }//GEN-LAST:event_mnuTixPendingActionPerformed

    private void mnuTixResolveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTixResolveActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "RESOLVED");
            param.put("showType", "ISSUE - TICKET");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repResolvedTix.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }//GEN-LAST:event_mnuTixResolveActionPerformed

    private void mnuTixCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuTixCloseActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "CLOSED");
            param.put("showType", "ISSUE - TICKET");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repClosedTix.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }//GEN-LAST:event_mnuTixCloseActionPerformed

    private void mnuCRUnassignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCRUnassignActionPerformed
                getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "PENDING");
            param.put("showType", "CHANGE REQUEST");
            param.put("showAssigned", "UNASSIGNED");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repUnassignedReq.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_mnuCRUnassignActionPerformed

    private void mnuCRPendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCRPendingActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "PENDING");
            param.put("showType", "CHANGE REQUEST");
            param.put("showAssigned", "UNASSIGNED");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repPendingReq.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }//GEN-LAST:event_mnuCRPendingActionPerformed

    private void mnuCRResolvedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCRResolvedActionPerformed
        getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "RESOLVED");
            param.put("showType", "CHANGE REQUEST");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repResolvedReq.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_mnuCRResolvedActionPerformed

    private void mnuCRClosedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCRClosedActionPerformed
                getDate();
        Map param = new HashMap();
            param.put("dateFrom",today.withDayOfMonth(1));
            param.put("dateTo", today.withDayOfMonth(today.lengthOfMonth()));
            param.put("showStatus", "CLOSED");
            param.put("showType", "CHANGE REQUEST");
        try{
            conn.close();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbticketing","root","root");
            JasperDesign jd = JRXmlLoader.load(new File("src\\reports\\repClosedReq.jrxml"));
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, param,conn);
            JasperViewer.viewReport(jp,false);

        }catch(ClassNotFoundException | SQLException | JRException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }//GEN-LAST:event_mnuCRClosedActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        try{
            frmDashboard obj = new frmDashboard();
            obj.setVisible(true);
            this.dispose();
            rs.close();
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();     
        }
    }//GEN-LAST:event_btnDashboardActionPerformed

    private void mnuClientMasterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuClientMasterActionPerformed
        try{
            frmClientDetails obj = new frmClientDetails();
            obj.setVisible(true);
            rs.close();
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();     
        }
    }//GEN-LAST:event_mnuClientMasterActionPerformed

    private void mnuDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuDashboardActionPerformed
        try{
            frmDashboard obj = new frmDashboard();
            obj.setVisible(true);
            this.dispose();
            rs.close();
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();     
        }
    }//GEN-LAST:event_mnuDashboardActionPerformed

    private void mnuUserMasterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuUserMasterActionPerformed
        try{
            frmUserMaster obj = new frmUserMaster();
            obj.setVisible(true);
            rs.close();
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();     
        }
    }//GEN-LAST:event_mnuUserMasterActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        disableTexts();
        clearTexts();
        btnAdd.setEnabled(true);
        btnEdit.setEnabled(true);
    }//GEN-LAST:event_btnCancelActionPerformed

    private void mnuLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuLogoutActionPerformed
        try{
            frmLogin obj = new frmLogin();
            obj.setVisible(true);
            rs.close();
            conn.close();
            pstmt.close();
        }catch(SQLException e){
            e.getMessage();     
        }    
    }//GEN-LAST:event_mnuLogoutActionPerformed

    private void mnuExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuExitActionPerformed
       int itemSelected = JOptionPane.showConfirmDialog(this, "EXIT THE SYSTEM?","EXIT",JOptionPane.YES_NO_OPTION);
       if (itemSelected == JOptionPane.YES_OPTION){
            this.dispose();
            System.exit(0);
       }
    }//GEN-LAST:event_mnuExitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(fmrTicketing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(fmrTicketing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(fmrTicketing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(fmrTicketing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new fmrTicketing().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnShow;
    private javax.swing.JComboBox<String> cmbAssignedTo;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JComboBox<String> cmbClient;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JComboBox<String> cmbType;
    private javax.swing.JComboBox<String> cmbTypeCategory;
    private com.toedter.calendar.JDateChooser dateFrom;
    private com.toedter.calendar.JDateChooser dateTicket;
    private com.toedter.calendar.JDateChooser dateTo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblID;
    private javax.swing.JMenu menu4;
    private javax.swing.JMenuItem mnuCRClosed;
    private javax.swing.JMenuItem mnuCRPending;
    private javax.swing.JMenuItem mnuCRResolved;
    private javax.swing.JMenuItem mnuCRUnassign;
    private javax.swing.JMenuItem mnuChangePassword;
    private javax.swing.JMenuItem mnuClientMaster;
    private javax.swing.JMenuItem mnuDashboard;
    private javax.swing.JMenuItem mnuExit;
    private javax.swing.JMenuItem mnuLogout;
    private javax.swing.JMenuItem mnuTixClose;
    private javax.swing.JMenuItem mnuTixPending;
    private javax.swing.JMenuItem mnuTixResolve;
    private javax.swing.JMenuItem mnuTixUnassign;
    private javax.swing.JMenuItem mnuUserMaster;
    private javax.swing.JTable tblTicket;
    private javax.swing.JLabel txtAssignee;
    private javax.swing.JTextArea txtDescription;
    // End of variables declaration//GEN-END:variables
}
